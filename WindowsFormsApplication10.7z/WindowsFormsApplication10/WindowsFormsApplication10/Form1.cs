﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication10
{

    public partial class Form1 : Form
    {
        static int[,] a2 = new int[6, 6];

        class mazee
        {
            private void writefile(int[,] a2)
            {
                string fname = @"C:\Users\zaid\Desktop\t.txt";
                if (!File.Exists(fname))
                {
                    using (StreamWriter sw =new StreamWriter(fname))
                    {
                        for (int i = 0; i <= a2.GetUpperBound(0); i++)
                        {
                            int j = 0;

                            while (j != 6)
                            {


                                sw.WriteLine(a2[i, j]);
                                j++;


                            }
                        }
                    }
                }
            }

            private bool check(int[,] a, int x, int y ,int n)
            {
                if (x >= 0 && y >= 0 && x < n && y < n && a[x, y] == 1)
                {
                    return true;
                }
                return false;
            }
            public bool sol(int[,] a, int x, int y ,int n,string dir)
            {
               
                if (x == 5 - 1 && y == 6 - 1)
                {
                    a2[x, y] = 1;
                    writefile(a2);
                    return true;
                }
                if (check(a, x, y,n) == true)
                {
                    a2[x, y] = 1;

                    if (dir != "up" && sol(a, x + 1, y,n,"down") == true)
                    {
                        return true;

                    }

                    if (dir!="left" && sol(a, x, y + 1,n,"right") == true)
                    {
                        return true;

                    }
                   if (dir!="down"&&sol(a, x - 1, y,n,"up") == true)
                    {
                        return true;

                    }

                    if (dir!="right"&&sol(a, x, y - 1,n,"left") == true)
                    {
                        return true;

                    }
                    a2[x, y] = 0;
                }

                return false;
            }
        }
        
        static int[,] a = new int[6, 6];

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            string fileName = @"C:\Users\zaid\Desktop\t.txt";
            if (System.IO.File.Exists(fileName))
            {

                using (System.IO.StreamReader sr = new StreamReader(fileName))
                {

                    String input;
                    for (int i = 0; i <= a.GetUpperBound(0); i++)
                    {
                        int j = 0;

                        while (j != 6 && (input = sr.ReadLine()) != null)
                        {

                            
                            a[i, j] = int.Parse(input);
                            j++;


                        }
                    }


                }

            }

            else
            {
                MessageBox.Show("File not found!");

            }
            label1.Text = Convert.ToString(a[0, 0]);
            label2.Text = Convert.ToString(a[0, 1]);
            label3.Text = Convert.ToString(a[0, 2]);
            label4.Text = Convert.ToString(a[0, 3]);
            label5.Text = Convert.ToString(a[0, 4]);
            label55.Text = Convert.ToString(a[0, 5]);
            label6.Text = Convert.ToString(a[1, 0]);
            label7.Text = Convert.ToString(a[1, 1]);
            label8.Text = Convert.ToString(a[1, 2]);
            label9.Text = Convert.ToString(a[1, 3]);
            label10.Text = Convert.ToString(a[1, 4]);
            label54.Text = Convert.ToString(a[1, 5]);
            label11.Text = Convert.ToString(a[2, 0]);
            label12.Text = Convert.ToString(a[2, 1]);
            label13.Text = Convert.ToString(a[2, 2]);
            label14.Text = Convert.ToString(a[2, 3]);
            label15.Text = Convert.ToString(a[2, 4]);
            label53.Text = Convert.ToString(a[2, 5]);
            label16.Text = Convert.ToString(a[3, 0]);
            label17.Text = Convert.ToString(a[3, 1]);
            label18.Text = Convert.ToString(a[3, 2]);
            label19.Text = Convert.ToString(a[3, 3]);
            label20.Text = Convert.ToString(a[3, 4]);
            label52.Text = Convert.ToString(a[3, 5]);
            label21.Text = Convert.ToString(a[4, 0]);
            label22.Text = Convert.ToString(a[4, 1]);
            label23.Text = Convert.ToString(a[4, 2]);
            label24.Text = Convert.ToString(a[4, 3]);
            label25.Text = Convert.ToString(a[4, 4]);
            label51.Text = Convert.ToString(a[4, 5]);
            label57.Text = Convert.ToString(a[5, 0]);
            label58.Text = Convert.ToString(a[5, 1]);
            label59.Text = Convert.ToString(a[5, 2]);
            label60.Text = Convert.ToString(a[5, 3]);
            label61.Text = Convert.ToString(a[5, 4]);
            label56.Text = Convert.ToString(a[5, 5]);
            

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string dir="down";
            int n = 6;
            int c = 0, d = 0;
            mazee b = new mazee();
            
            if (b.sol(a, c, d,n,dir) == true)
            {
                label26.Text = Convert.ToString(a2[0, 0]);
                label27.Text = Convert.ToString(a2[0, 1]);
                label28.Text = Convert.ToString(a2[0, 2]);
                label29.Text = Convert.ToString(a2[0, 3]);
                label30.Text = Convert.ToString(a2[0, 4]);
                label64.Text = Convert.ToString(a2[0, 5]);
                label31.Text = Convert.ToString(a2[1, 0]);
                label32.Text = Convert.ToString(a2[1, 1]);
                label33.Text = Convert.ToString(a2[1, 2]);
                label34.Text = Convert.ToString(a2[1, 3]);
                label35.Text = Convert.ToString(a2[1, 4]);
                label65.Text = Convert.ToString(a2[1, 5]);
                label36.Text = Convert.ToString(a2[2, 0]);
                label37.Text = Convert.ToString(a2[2, 1]);
                label38.Text = Convert.ToString(a2[2, 2]);
                label39.Text = Convert.ToString(a2[2, 3]);
                label40.Text = Convert.ToString(a2[2, 4]);
                label66.Text = Convert.ToString(a2[2, 5]);
                label41.Text = Convert.ToString(a2[3, 0]);
                label42.Text = Convert.ToString(a2[3, 1]);
                label43.Text = Convert.ToString(a2[3, 2]);
                label44.Text = Convert.ToString(a2[3, 3]);
                label45.Text = Convert.ToString(a2[3, 4]);
                label63.Text = Convert.ToString(a2[3, 5]);
                label46.Text = Convert.ToString(a2[4, 0]);
                label47.Text = Convert.ToString(a2[4, 1]);
                label48.Text = Convert.ToString(a2[4, 2]);
                label49.Text = Convert.ToString(a2[4, 3]);
                label50.Text = Convert.ToString(a2[4, 4]);
                label62.Text = Convert.ToString(a2[4, 5]);
                label70.Text = Convert.ToString(a2[5, 0]);
                label71.Text = Convert.ToString(a2[5, 1]);
                label72.Text = Convert.ToString(a2[5, 2]);
                label68.Text = Convert.ToString(a2[5, 3]);
                label69.Text = Convert.ToString(a2[5, 4]);
                label67.Text = Convert.ToString(a2[5, 5]);
                
            }
            else 
            {
                MessageBox.Show("No Path Found");
            }
        }
        private void label42_Click(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void label43_Click(object sender, EventArgs e)
        {

        }

        private void label44_Click(object sender, EventArgs e)
        {

        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label37_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label54_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click_1(object sender, EventArgs e)
        {

        }
    }
}
